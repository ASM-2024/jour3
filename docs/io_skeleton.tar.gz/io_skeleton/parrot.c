#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#define BUF_SIZE 256

void parrot(char *filename)
{
    /*
     * 1. Write the initial message onto stdout.
     *
     * 2. Read the user-input. Only consider the first character entered,
     * you can discard the rest.
     *
     * 3. Check that the given input is a number between 0 and 9, both
     * included.
     * If the input is not correct, use the warn(3) function and restart parrot.
     *
     * 4. Open the file at the path given in parameter.
     *
     * 5. Write the content of the file as many time as the number
     * the user entered previously.
     *
     * /!\ ALWAYS TAKE CARE OF POTENTIAL ERRORS! /!\
     */
}

int main(int argc, char **argv)
{
    // Check that the number of arguments given is equal to 2, exit otherwise.
    // Call parrot with the correct argument.
    return 0;
}
