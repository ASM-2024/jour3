#include <err.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

void my_puts(char *s)
{
    /*
     * Given a string s, print it on stdout.
     * However, remember the behaviour of puts(3),
     * since printing a string is not the only thing puts does.
     *
     * /!\ ALWAYS TAKE CARE OF POTENTIAL ERRORS! /!\
     */

    // TODO: Implement my_puts.
}

int main(void)
{
    /*
     * This main function is only here for you to briefly test your code.
     * You can hence do whatever you want with it.
     */

    return 0;
}
