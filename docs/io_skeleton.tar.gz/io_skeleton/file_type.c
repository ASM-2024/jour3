#include <err.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

void file_type(char *filename)
{
    /*
     * 1. Take a good look at the stat(2) man-page to see what you need
     * to declare first.
     *
     * 2. Once you called stat and it works, you can check whether it
     * is a regular file or a directory.
     *
     * /!\ ALWAYS TAKE CARE OF POTENTIAL ERRORS! /!\
     */

    // TODO: Implement file_type.
}

int main(int argc, char **argv)
{
    // TODO: Check that the number of arguments is equal to 2, exit otherwise.`
    return 0;
}
